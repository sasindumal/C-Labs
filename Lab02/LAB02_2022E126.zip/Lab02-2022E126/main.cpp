// MALHARA R.M.Y.S

// 2022/E/126

// EC2010

//Group: C

// Lab: 02

// Program Description: [insert brief description here]

// Certificate of Authenticity:

// I certify that the code in the method function main of this project

// is entirely my own work.

#include <iostream>

using namespace std;

int main()
{
    cout << "Hello world!" << endl;

    cout << "Welcome to the Programming!"<<endl;
    cout << "It's going to be an interesting module."<<"\n";


      double length = 10;
    cout<< length++ <<endl;
    cout<< ++length <<endl;
    cout<< ++length;
    return 0;
}
