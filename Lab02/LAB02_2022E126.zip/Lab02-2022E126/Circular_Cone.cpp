// MALHARA R.M.Y.S

// 2022/E/126

// EC2010

//Group: C

// Lab: 02

// Program Description: [insert brief description here]

// Certificate of Authenticity:

// I certify that the code in the method function main of this project

// is entirely my own work.

#include <iostream>

using namespace std;

int main()
{
    double r;
    double h;
    double v;
    double pi=3.14;


    cout<<"Enter the radius of a Circular cone:";
    cin>>r;

    cout<<"Enter the height of a Circular cone:";
    cin>>h;

    v=(pi*r*r*h)/3;

    cout<<"Volume of the Circular cone is = "<<v<<endl;


}
